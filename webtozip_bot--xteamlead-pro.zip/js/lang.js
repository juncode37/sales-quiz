/* js/lang.js */
window.I18N = (() => {
    const translations = {
        ru: {
            // --- UI ---
            hero_btn: "Пройти квиз",
            hiring_now: "Набор открыт",
            hero_title: `Работа в Арбитраже.<br><span class="text-grad">Бонус за выход</span> — сразу.`,
            hero_sub: "Ищем опытных медиабайеров и тимлидов. Пройди скоринг за 1 минуту и получи персональный оффер.",
            bonus_buyer: "Sign-on бонус (Buyer)",
            bonus_lead: "Для Team Lead + Команда",
            hero_cta: "Начать квиз",
            hero_note: "Без лишних созвонов. Ответ в течение дня.",
            how_it_works: "Как это работает",
            step1_t: "Анкета",
            step1_d: "90 секунд на ответы",
            step2_t: "Оффер",
            step2_d: "Мы оценим опыт и стек",
            step3_t: "Бонус",
            step3_d: "Выплата после выхода",
            
            sec_roles_title: "Кого ищем",
            role_buy_t: "Медиабайеры",
            role_buy_d: "Опыт в FB/Google/TikTok/UAC, понимание трекинга, тестирование связок, дисциплина в метриках.",
            role_lead_t: "Тимлиды",
            role_lead_d: "Управление командой, процессы, ответственность за P&L, умение масштабировать и удерживать ROI.",
            role_team_t: "Команды",
            role_team_d: "Готовые роли (дизайнер/фарм/аналитика), своя инфраструктура или готовность быстро выстроить.",

            privacy: "Политика конфиденциальности",
            terms: "Условия использования",
            cookie_text: "Мы используем cookie для улучшения работы сайта.",
            
            // --- QUIZ UI ---
            quiz_title: "Анкета кандидата",
            btn_back: "Назад",
            btn_next: "Далее",
            btn_submit: "Отправить",
            btn_close: "Закрыть",
            err_fill: "Пожалуйста, заполните поле.",
            err_tg: "Укажите Telegram username (например: @username).",
            step_count: "Шаг {x} из {y}",
            
            // --- QUIZ QUESTIONS ---
            // 1. Role
            q_role_t: "Кто вы?",
            q_role_buy: "Media Buyer (байер)",
            q_role_lead: "Team Lead (с командой / набираю)",
            // 2. Source
            q_src_t: "Основной источник трафика",
            q_src_fb: "Facebook / Meta",
            q_src_gg: "Google Ads",
            q_src_tt: "TikTok Ads",
            q_src_uac: "UAC / App",
            q_src_oth: "Другое",
            // 3. Exp
            q_exp_t: "Опыт в арбитраже",
            q_exp_03: "0–3 месяца",
            q_exp_312: "3–12 месяцев",
            q_exp_12: "1–2 года",
            q_exp_2p: "2+ лет",
            // 4. Spend
            q_spend_t: "Средний спенд в месяц",
            // 5. Vertical
            q_vert_t: "Основная вертикаль",
            q_vert_gamb: "Gambling",
            q_vert_nutra: "Nutra",
            q_vert_crypto: "Crypto/Forex",
            q_vert_date: "Dating",
            q_vert_sweep: "Sweepstakes",
            q_vert_oth: "Другое",
            // 6. Geo
            q_geo_t: "Гео (основное)",
            q_geo_sel: "Выберите...",
            q_geo_mix: "Микс",
            q_geo_hint: "Если у вас сложнее — выберите «Микс», уточним на созвоне.",
            // 7. Team Size
            q_team_t: "Размер команды",
            q_team_solo: "Пока один (собираю)",
            q_team_24: "2–4 человека",
            q_team_59: "5–9 человек",
            q_team_10: "10+ человек",
            // 8. Name
            q_name_t: "Как к вам обращаться?",
            q_name_ph: "Имя или ник",
            // 9. TG
            q_tg_t: "Telegram для связи",
            q_tg_hint: "Укажите @username. Мы напишем только по заявке.",

            // --- THANKS ---
            home_btn: "На главную",
            status_ok: "Заявка принята",
            thx_title: "Спасибо! Мы получили вашу анкету",
            thx_desc: "Мы свяжемся с вами в Telegram. Если вы тимлид — подготовьте кратко: состав команды, роли, спенд и гео.",
            mini_step: "Следующий шаг",
            mini_step_v: "сообщение в TG",
            mini_time: "Срок",
            mini_time_v: "в ближайшее время",
            res_title: "Подпишитесь на наши ресурсы",
            res_fb_t: "Канал про Facebook-трафик",
            res_fb_d: "Кейсы, связки, модерация, креативы и масштабирование в Meta.",
            res_google_t: "Канал про Google-трафик",
            res_google_d: "Стратегии, PMax/поиск, модерация, оптимизация и масштабирование.",
            res_inapp_t: "Канал про In-App",
            res_inapp_d: "In-app сети, креативы, аналитика и масштабирование мобильного трафика.",
            res_primax_t: "Агентство PRIMAX",
            res_primax_d: "Аренда аккаунтов Google / Facebook / Moloco и сопровождение запусков.",
            res_white_t: "White.Expert — генератор вайтов",
            res_white_d: "Генерация white-page под модерацию. Быстро, удобно, под разные форматы.",
            btn_open: "Открыть",
            thx_footer: "Если хотите ускорить процесс — напишите сразу: ваш источник, спенд, вертикаль и гео."
        },
        ua: {
            // --- UI ---
            hero_btn: "Пройти квіз",
            hiring_now: "Набір відкрито",
            hero_title: `Робота в Арбітражі.<br><span class="text-grad">Бонус за вихід</span> — відразу.`,
            hero_sub: "Шукаємо досвідчених медіабаєрів та тімлідів. Пройди скоринг за 1 хвилину та отримай персональний офер.",
            bonus_buyer: "Sign-on бонус (Buyer)",
            bonus_lead: "Для Team Lead + Команда",
            hero_cta: "Почати квіз",
            hero_note: "Без зайвих дзвінків. Відповідь протягом дня.",
            how_it_works: "Як це працює",
            step1_t: "Анкета",
            step1_d: "90 секунд на відповіді",
            step2_t: "Офер",
            step2_d: "Ми оцінимо досвід та стек",
            step3_t: "Бонус",
            step3_d: "Виплата після виходу",
            sec_roles_title: "Кого шукаємо",
            role_buy_t: "Медіабаєри",
            role_buy_d: "Досвід у FB/Google/TikTok/UAC, розуміння трекінгу, тестування зв'язок, дисципліна у метриках.",
            role_lead_t: "Тімліди",
            role_lead_d: "Управління командою, процеси, відповідальність за P&L, вміння масштабувати та утримувати ROI.",
            role_team_t: "Команди",
            role_team_d: "Готові ролі (дизайнер/фарм/аналітика), своя інфраструктура чи готовність швидко побудувати.",
            privacy: "Політика конфіденційності",
            terms: "Умови використання",
            cookie_text: "Ми використовуємо cookie для покращення роботи сайту.",

            // --- QUIZ UI ---
            quiz_title: "Анкета кандидата",
            btn_back: "Назад",
            btn_next: "Далі",
            btn_submit: "Надіслати",
            btn_close: "Закрити",
            err_fill: "Будь ласка, заповніть поле.",
            err_tg: "Вкажіть Telegram username (наприклад: @username).",
            step_count: "Крок {x} з {y}",

            // --- QUIZ QUESTIONS ---
            q_role_t: "Хто ви?",
            q_role_buy: "Media Buyer (баєр)",
            q_role_lead: "Team Lead (з командою / набираю)",
            q_src_t: "Основне джерело трафіку",
            q_src_fb: "Facebook / Meta",
            q_src_gg: "Google Ads",
            q_src_tt: "TikTok Ads",
            q_src_uac: "UAC / App",
            q_src_oth: "Інше",
            q_exp_t: "Досвід в арбітражі",
            q_exp_03: "0–3 місяці",
            q_exp_312: "3–12 місяців",
            q_exp_12: "1–2 роки",
            q_exp_2p: "2+ років",
            q_spend_t: "Середній спенд на місяць",
            q_vert_t: "Основна вертикаль",
            q_vert_gamb: "Gambling",
            q_vert_nutra: "Nutra",
            q_vert_crypto: "Crypto/Forex",
            q_vert_date: "Dating",
            q_vert_sweep: "Sweepstakes",
            q_vert_oth: "Інше",
            q_geo_t: "Гео (основне)",
            q_geo_sel: "Оберіть...",
            q_geo_mix: "Мікс",
            q_geo_hint: "Якщо у вас складніше — оберіть «Мікс», уточнимо на зідзвоні.",
            q_team_t: "Розмір команди",
            q_team_solo: "Поки один (збираю)",
            q_team_24: "2–4 людини",
            q_team_59: "5–9 людей",
            q_team_10: "10+ людей",
            q_name_t: "Як до вас звертатися?",
            q_name_ph: "Ім'я або нік",
            q_tg_t: "Telegram для зв'язку",
            q_tg_hint: "Вкажіть @username. Ми напишемо тільки за заявкою.",

            // --- THANKS ---
            home_btn: "На головну",
            status_ok: "Заявка прийнята",
            thx_title: "Дякуємо! Ми отримали вашу анкету",
            thx_desc: "Ми зв'яжемося з вами в Telegram. Якщо ви тімлід — підготуйте коротко: склад команди, ролі, спенд і гео.",
            mini_step: "Наступний крок",
            mini_step_v: "повідомлення в TG",
            mini_time: "Термін",
            mini_time_v: "найближчим часом",
            res_title: "Підпишіться на наші ресурси",
            res_fb_t: "Канал про Facebook-трафік",
            res_fb_d: "Кейси, зв'язки, модерація, креативи та масштабування в Meta.",
            res_google_t: "Канал про Google-трафік",
            res_google_d: "Стратегії, PMax/пошук, модерація, оптимізація та масштабування.",
            res_inapp_t: "Канал про In-App",
            res_inapp_d: "In-app мережі, креативи, аналітика та масштабування мобільного трафіку.",
            res_primax_t: "Агентство PRIMAX",
            res_primax_d: "Оренда акаунтів Google / Facebook / Moloco та супровід запусків.",
            res_white_t: "White.Expert — генератор вайтів",
            res_white_d: "Генерація white-page під модерацію. Швидко, зручно, під різні формати.",
            btn_open: "Відкрити",
            thx_footer: "Якщо хочете прискорити процес — напишіть відразу: ваше джерело, спенд, вертикаль і гео."
        },
        en: {
            // --- UI ---
            hero_btn: "Take Quiz",
            hiring_now: "Hiring Now",
            hero_title: `Affiliate Marketing Jobs.<br><span class="text-grad">Sign-on Bonus</span> included.`,
            hero_sub: "Looking for Media Buyers and Team Leads. Take a 1-minute scoring quiz and get a personal offer.",
            bonus_buyer: "Sign-on Bonus (Buyer)",
            bonus_lead: "For Team Lead + Team",
            hero_cta: "Start Quiz",
            hero_note: "No unnecessary calls. Feedback within 24h.",
            how_it_works: "How it works",
            step1_t: "Quiz",
            step1_d: "90 seconds to complete",
            step2_t: "Offer",
            step2_d: "We evaluate stack & exp",
            step3_t: "Bonus",
            step3_d: "Paid after probation",
            sec_roles_title: "Who we are looking for",
            role_buy_t: "Media Buyers",
            role_buy_d: "Exp in FB/Google/TikTok/UAC, tracking knowledge, creative testing, discipline in metrics.",
            role_lead_t: "Team Leads",
            role_lead_d: "Team management, processes, P&L responsibility, scaling skills and ROI maintenance.",
            role_team_t: "Teams",
            role_team_d: "Ready-made roles (designer/farm/analytics), own infrastructure or ready to build fast.",
            privacy: "Privacy Policy",
            terms: "Terms of Use",
            cookie_text: "We use cookies to improve your experience.",

            // --- QUIZ UI ---
            quiz_title: "Candidate Application",
            btn_back: "Back",
            btn_next: "Next",
            btn_submit: "Submit",
            btn_close: "Close",
            err_fill: "Please fill out this field.",
            err_tg: "Please enter a valid Telegram username (@username).",
            step_count: "Step {x} of {y}",

            // --- QUIZ QUESTIONS ---
            q_role_t: "Who are you?",
            q_role_buy: "Media Buyer",
            q_role_lead: "Team Lead (w/ team)",
            q_src_t: "Primary Traffic Source",
            q_src_fb: "Facebook / Meta",
            q_src_gg: "Google Ads",
            q_src_tt: "TikTok Ads",
            q_src_uac: "UAC / App",
            q_src_oth: "Other",
            q_exp_t: "Affiliate Experience",
            q_exp_03: "0–3 months",
            q_exp_312: "3–12 months",
            q_exp_12: "1–2 years",
            q_exp_2p: "2+ years",
            q_spend_t: "Average Monthly Spend",
            q_vert_t: "Primary Vertical",
            q_vert_gamb: "Gambling",
            q_vert_nutra: "Nutra",
            q_vert_crypto: "Crypto/Forex",
            q_vert_date: "Dating",
            q_vert_sweep: "Sweepstakes",
            q_vert_oth: "Other",
            q_geo_t: "Primary Geo",
            q_geo_sel: "Select...",
            q_geo_mix: "Mix",
            q_geo_hint: "If complex, select 'Mix', we'll discuss on call.",
            q_team_t: "Team Size",
            q_team_solo: "Solo (building now)",
            q_team_24: "2–4 people",
            q_team_59: "5–9 people",
            q_team_10: "10+ people",
            q_name_t: "What should we call you?",
            q_name_ph: "Name or Nickname",
            q_tg_t: "Telegram Contact",
            q_tg_hint: "Use @username format. We contact only for this offer.",

            // --- THANKS ---
            home_btn: "Back Home",
            status_ok: "Application Received",
            thx_title: "Thanks! We received your application",
            thx_desc: "We will contact you on Telegram. If you are a Team Lead, please prepare briefly: team structure, roles, spend, and geo.",
            mini_step: "Next step",
            mini_step_v: "TG message",
            mini_time: "Timeframe",
            mini_time_v: "shortly",
            res_title: "Subscribe to our resources",
            res_fb_t: "Facebook Traffic Channel",
            res_fb_d: "Cases, funnels, moderation, creatives, and scaling in Meta.",
            res_google_t: "Google Traffic Channel",
            res_google_d: "Strategies, PMax/Search, moderation, optimization, and scaling.",
            res_inapp_t: "In-App Channel",
            res_inapp_d: "In-app networks, creatives, analytics, and mobile traffic scaling.",
            res_primax_t: "PRIMAX Agency",
            res_primax_d: "Google / Facebook / Moloco account rental and launch support.",
            res_white_t: "White.Expert — White Page Gen",
            res_white_d: "White-page generation for moderation. Fast, convenient, various formats.",
            btn_open: "Open",
            thx_footer: "To speed up the process, write to us immediately: your source, spend, vertical, and geo."
        }
    };

    const getBrowserLang = () => {
        // 1. URL Param (Highest priority)
        const urlParams = new URLSearchParams(window.location.search);
        if(urlParams.get('lang')) return urlParams.get('lang');

        // 2. Local Storage (Saved choice)
        const saved = localStorage.getItem('site_lang');
        if(saved && translations[saved]) return saved;

        // 3. Browser System (Default)
        const navLang = navigator.language || navigator.userLanguage;
        if (navLang.includes('ru')) return 'ru';
        if (navLang.includes('uk') || navLang.includes('ua')) return 'ua';
        return 'en';
    };

    const setLang = (lang) => {
        if (!translations[lang]) lang = 'en';
        
        // Save choice
        localStorage.setItem('site_lang', lang);
        document.documentElement.lang = lang;
        
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (translations[lang][key]) {
                el.innerHTML = translations[lang][key];
            }
        });

        const curLangEl = document.getElementById('curLang');
        if(curLangEl) curLangEl.innerText = lang.toUpperCase();

        document.querySelectorAll('.lang-item').forEach(item => {
            item.classList.remove('active');
            if(item.dataset.val === lang) item.classList.add('active');
        });
    };

    const t = (key) => {
        const lang = document.documentElement.lang || 'en';
        if(translations[lang] && translations[lang][key]) {
            return translations[lang][key];
        }
        return key;
    };

    const initDropdown = () => {
        const btn = document.getElementById('langToggle');
        const menu = document.getElementById('langMenu');
        
        if(!btn || !menu) return;

        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            menu.classList.toggle('show');
        });

        document.addEventListener('click', () => {
            menu.classList.remove('show');
        });

        document.querySelectorAll('.lang-item').forEach(item => {
            item.addEventListener('click', () => {
                setLang(item.dataset.val);
            });
        });
    };

    const currentLang = getBrowserLang();
    setLang(currentLang);
    document.addEventListener('DOMContentLoaded', initDropdown);

    return { 
        current: currentLang,
        t: t 
    };
})();